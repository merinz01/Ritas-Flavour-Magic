const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const jwt = require ('jsonwebtoken');
const ProductData = require('../models/Productdata');
const MasalaData = require('../models/masaladata');
const PickleData = require ('../models/pickle');
const PasteData = require ('../models/paste');
const SpiceData = require ('../models/spice');
const User = require('../models/user');


const db = 'mongodb+srv://user_products:pro@mycluster.o8bqc.mongodb.net/flavoursDB?retryWrites=true&w=majority';
// checking connection to db
mongoose.connect(db,function(err){
    if (err){
        console.log('CONNECTION ERROR' + err)
    } else {
        console.log('Connected to flavoursDB in mongodb')
    }
});

function verifyToken(req ,res, next){
    if (!res.headers.authorization){
        return res.status(401).send('Unauthorized access')
    }
    let token = req.headers.authorization.split(' ')[1]
    if (token === 'null'){
        alert('user not available')
        return res.status(401).send('Unauthorised Access')  
    }
        let payload = jwt.verify(token,'secretKey')
        if (!payload){
        return res.status(401).send('Unauthorised Access')
        }
        req.userId = payload.subject
        next()
        
    }

  
router.get('/',(req,res)=>{
    res.send("Hello from API");
})


router.get('/products',(req,res)=>{
   res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS");

    ProductData.find()
    .then((products)=>{
        res.send(products);
    });
 
});

router.get('/masalas',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
     res.header("Access-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS");
 
     MasalaData.find()
     .then((masalas)=>{
         res.send(masalas);
     });
  
 });


 router.get('/pickles',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
     res.header("Access-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS");
 
     PickleData.find()
     .then((pickles)=>{
         res.send(pickles);
     });
  
 });
 router.get('/spices',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
     res.header("Access-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS");
 
     SpiceData.find()
     .then((spices)=>{
         res.send(spices);
     });
  
 });
 router.get('/pastes',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
     res.header("Access-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS");
 
     PasteData.find()
     .then((pastes)=>{
         res.send(pastes);
     });
  
 });

// BREAKFAST
 router.post('/add',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Methods:GET,POST,PUT,PATCH,DELETE,OPTIONS");
    console.log(req.body);

    var product = {
        category:req.body.product.category,
        productId:req.body.product.productId,
        productName:req.body.product.productName,
        productCode:req.body.product.productCode,
        description:req.body.product.description,
        hundredgm:req.body.product.hundredgm,
        twohundredgm:req.body.product.twohundredgm,
        fivehundredgm:req.body.product.fivehundredgm,
        onekilo:req.body.product.onekilo,
        price:req.body.product.price,
        imageUrl:req.body.product.imageUrl,
    }
    
    var product = new ProductData(product);
    product.save()

});

 router.get('/edit/:id',function(req,res){

    ProductData.findById(req.params.id,(err,data)=>{
        if (!err) {return res.send(data)}
        else { console.log('Error in retireiving product details for updation')}
    });
 
 
 
 router.post('/update/:id',function(req,res){
     ProductData.findByIdAndUpdate(req.params.id,
         { $set: req.body },
                 (err,data)=>{
                     if (!err) { res.status(200).send(data);
                                 console.log('Product update successfull')}
                     else { console.log('Error in employee update' + err)}
                 })
    })
    })
 
 router.delete('/delete/:id',(req,res)=>{
      
   ProductData.findByIdAndDelete(req.params.id,(err,doc)=>{
         if(err){
             console.log(err);
             res.send(err);
         }else{
         res.send(doc);
         console.log('deleted product');
     }
             })
 })

//  MASALAS
router.post('/addMasalas',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Methods:GET,POST,PUT,PATCH,DELETE,OPTIONS");
    console.log(req.body);

    var product = {
        category:req.body.masala.category,
        productId:req.body.masala.productId,
        productName:req.body.masala.productName,
        productCode:req.body.masala.productCode,
        description:req.body.masala.description,
        hundredgm:req.body.masala.hundredgm,
        twohundredgm:req.body.masala.twohundredgm,
        fivehundredgm:req.body.masala.fivehundredgm,
        onekilo:req.body.masala.onekilo,
        price:req.body.masala.price,
        imageUrl:req.body.masala.imageUrl,
    }
    
    var product = new MasalaData(product);
    product.save()

});

 router.get('/editMasalas/:id',function(req,res){

    MasalaData.findById(req.params.id,(err,data)=>{
        if (!err) {return res.send(data)}
        else { console.log('Error in retireiving product details for updation')}
    });
 
 
 
 router.post('/updateMasalas/:id',function(req,res){
    MasalaData.findByIdAndUpdate(req.params.id,
         { $set: req.body },
                 (err,data)=>{
                     if (!err) { res.status(200).send(data);
                                 console.log('Product update successful')}
                     else { console.log('Error in masala update' + err)}
                 })
    })
    })
 
 router.delete('/deleteMasalas/:id',(req,res)=>{
      
    MasalaData.findByIdAndDelete(req.params.id,(err,doc)=>{
         if(err){
             console.log(err);
             res.send(err);
         }else{
         res.send(doc);
         console.log('deleted product');
     }
             })
 })

//  PICKLES
router.post('/addPickles',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Methods:GET,POST,PUT,PATCH,DELETE,OPTIONS");
    console.log(req.body);

    var product = {
        category:req.body.pickle.category,
        productId:req.body.pickle.productId,
        productName:req.body.pickle.productName,
        productCode:req.body.pickle.productCode,
        description:req.body.pickle.description,
        hundredgm:req.body.pickle.hundredgm,
        twohundredgm:req.body.pickle.twohundredgm,
        fivehundredgm:req.body.pickle.fivehundredgm,
        onekilo:req.body.pickle.onekilo,
        price:req.body.pickle.price,
        imageUrl:req.body.pickle.imageUrl,
    }
    
    var product = new PickleData(product);
    product.save()

});

 router.get('/editPickles/:id',function(req,res){

    PickleData.findById(req.params.id,(err,data)=>{
        if (!err) {return res.send(data)}
        else { console.log('Error in retireiving product details for updation')}
    });
 
 
 
 router.post('/updatePickles/:id',function(req,res){
    PickleData.findByIdAndUpdate(req.params.id,
         { $set: req.body },
                 (err,data)=>{
                     if (!err) { res.status(200).send(data);
                                 console.log('Product update successfull')}
                     else { console.log('Error in pickle update' + err)}
                 })
    })
    })
 
 router.delete('/deletePickles/:id',(req,res)=>{
      
    PickleData.findByIdAndDelete(req.params.id,(err,doc)=>{
         if(err){
             console.log(err);
             res.send(err);
         }else{
         res.send(doc);
         console.log('deleted product');
     }
             })
 })


// PASTES
router.post('/addPastes',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Methods:GET,POST,PUT,PATCH,DELETE,OPTIONS");
    console.log(req.body);

    var product = {
        category:req.body.paste.category,
        productId:req.body.paste.productId,
        productName:req.body.paste.productName,
        productCode:req.body.paste.productCode,
        description:req.body.paste.description,
        hundredgm:req.body.paste.hundredgm,
        twohundredgm:req.body.paste.twohundredgm,
        fivehundredgm:req.body.paste.fivehundredgm,
        onekilo:req.body.paste.onekilo,
        price:req.body.paste.price,
        imageUrl:req.body.paste.imageUrl,
    }
    
    var product = new PasteData(product);
    product.save()

});

 router.get('/editPastes/:id',function(req,res){

    PasteData.findById(req.params.id,(err,data)=>{
        if (!err) {return res.send(data)}
        else { console.log('Error in retireiving product details for updation')}
    });
 
 
 
 router.post('/updatePastes/:id',function(req,res){
    PasteData.findByIdAndUpdate(req.params.id,
         { $set: req.body },
                 (err,data)=>{
                     if (!err) { res.status(200).send(data);
                                 console.log('Product update successfull')}
                     else { console.log('Error in paste update' + err)}
                 })
    })
    })
 
 router.delete('/deletePastes/:id',(req,res)=>{
      
    PasteData.findByIdAndDelete(req.params.id,(err,doc)=>{
         if(err){
             console.log(err);
             res.send(err);
         }else{
         res.send(doc);
         console.log('deleted product');
     }
             })
 })


// SPICES
router.post('/addSpices',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Methods:GET,POST,PUT,PATCH,DELETE,OPTIONS");
    console.log(req.body);

    var product = {
        category:req.body.spice.category,
        productId:req.body.spice.productId,
        productName:req.body.spice.productName,
        productCode:req.body.spice.productCode,
        description:req.body.spice.description,
        hundredgm:req.body.spice.hundredgm,
        twohundredgm:req.body.spice.twohundredgm,
        fivehundredgm:req.body.spice.fivehundredgm,
        onekilo:req.body.spice.onekilo,
        price:req.body.spice.price,
        imageUrl:req.body.spice.imageUrl,
    }
    
    var product = new SpiceData(product);
    product.save()

});

 router.get('/editSpices/:id',function(req,res){

    SpiceData.findById(req.params.id,(err,data)=>{
        if (!err) {return res.send(data)}
        else { console.log('Error in retireiving product details for updation')}
    });
 
 
 router.post('/updateSpices/:id',function(req,res){
    SpiceData.findByIdAndUpdate(req.params.id,
         { $set: req.body },
                 (err,data)=>{
                     if (!err) { res.status(200).send(data);
                                 console.log('Product update successfull')}
                     else { console.log('Error in spice update' + err)}
                 })
    })
    })
 
 router.delete('/deleteSpices/:id',(req,res)=>{
      
    SpiceData.findByIdAndDelete(req.params.id,(err,doc)=>{
         if(err){
             console.log(err);
             res.send(err);
         }else{
         res.send(doc);
         console.log('deleted product');
     }
             })
 })

// REGISTER
router.post('/register',(req,res)=>{
    let userData = req.body;
    let user = new User(userData);
    user.save((err,registeredUser)=>
    {
        if (err){
            console.log(err)
        }else
            {
                let payload = {subject: registeredUser._id}
                let token = jwt.sign(payload,'secretKey')
                res.status(200).send({token})
            }
                // res.status(200).send(registeredUser);
        
    })
})

// LOGIN
router.post('/login', (req,res)=>
{
    let userData = req.body;
    console.log(userData);
    User.findOne({email:userData.email},(err,user)=>
    {
        if (err){
            
            console.log("this is error"+err);
        }else
            {
                if(!user)
                {
                    // alert('Invalid Email Id')
                    console.log('Invalid Email');
                    res.status(401).send('Invalid Email')

                } 
                else if(user.password !== userData.password)
                {
                    // alert('Invalid Password')
                    console.log('Invalid password');
                    res.status(401).send('Invalid password')
                } else {
                    let payload = {subject: user._id}
                    let token = jwt.sign(payload,'secretKey')
                    res.status(200).send({token})
                    // res.status(200).send(user)
                }
        }
    })
})

module.exports = router;