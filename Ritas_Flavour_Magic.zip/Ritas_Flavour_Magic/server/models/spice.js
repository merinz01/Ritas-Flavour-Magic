const mongoose = require('mongoose');
const Schema = mongoose.Schema;

var SpiceSchema = new Schema({
    category:String,
    productId:Number,
    productName:String,
    productCode:String,
    description:String,
    hundredgm:Number,
    twohundredgm:Number,
    fivehundredgm:Number,
    onekilo:Number,
    price:String,
    imageUrl:String
});

var Spicedata = mongoose.model('spice', SpiceSchema,'spices');

module.exports = Spicedata;