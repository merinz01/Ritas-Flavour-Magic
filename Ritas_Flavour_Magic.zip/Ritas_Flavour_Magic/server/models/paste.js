const mongoose = require('mongoose');
const Schema = mongoose.Schema;

var PasteSchema = new Schema({
    category:String,
    productId:Number,
    productName:String,
    productCode:String,
    description:String,
    hundredgm:Number,
    twohundredgm:Number,
    fivehundredgm:Number,
    onekilo:Number,
    price:String,
    imageUrl:String
});

var Pastedata = mongoose.model('paste', PasteSchema,'pastes');

module.exports = Pastedata;