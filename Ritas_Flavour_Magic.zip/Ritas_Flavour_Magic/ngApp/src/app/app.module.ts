import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ProductListComponent } from './product-list/product-list.component';
import { LoginComponent } from './login/login.component';
import { ProductService } from './product.service';
import { UserService } from './user.service';
import { UserGuard } from './user.guard';
import { AdminGuard } from "./admin.guard";
import { RegisterComponent } from './register/register.component';
import { BreakfastComponent } from './breakfast/breakfast.component';
import { SpicesComponent } from './spices/spices.component';
import { MasalasComponent } from './masalas/masalas.component';
import { PicklesComponent } from './pickles/pickles.component';
import { PastesComponent } from './pastes/pastes.component';
import { NewProductComponent } from './new-product/new-product.component';
import { EditProductsComponent } from './edit-products/edit-products.component';
import { NewSpicesComponent } from './new-spices/new-spices.component';
import { NewMasalasComponent } from './new-masalas/new-masalas.component';
import { NewPastesComponent } from './new-pastes/new-pastes.component';
import { NewPicklesComponent } from './new-pickles/new-pickles.component';
import { EditSpicesComponent } from './edit-spices/edit-spices.component';
import { EditMasalasComponent } from './edit-masalas/edit-masalas.component';
import { EditPicklesComponent } from './edit-pickles/edit-pickles.component';
import { EditPastesComponent } from './edit-pastes/edit-pastes.component';
import { FooterComponent } from './footer/footer.component';
import {TokenInterceptorService } from './token-interceptor.service';
import { UsermasalaComponent } from './usermasala/usermasala.component';





@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    AboutusComponent,
    ProductsComponent,
    TestimonialsComponent,
    ContactusComponent,
    ProductListComponent,
    BreakfastComponent,
    SpicesComponent,
    LoginComponent,
    RegisterComponent,
    MasalasComponent,
    PicklesComponent,
    PastesComponent,
    NewProductComponent,
    EditProductsComponent,
    NewSpicesComponent,
    NewMasalasComponent,
    NewPastesComponent,
    NewPicklesComponent,
    EditSpicesComponent,
    EditMasalasComponent,
    EditPicklesComponent,
    EditPastesComponent,
    FooterComponent,
    UsermasalaComponent,
  
    
     ],
     
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
  ],
  providers: [ProductService,UserGuard,UserService,AdminGuard,
  {
    provide:HTTP_INTERCEPTORS,
    useClass:TokenInterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
