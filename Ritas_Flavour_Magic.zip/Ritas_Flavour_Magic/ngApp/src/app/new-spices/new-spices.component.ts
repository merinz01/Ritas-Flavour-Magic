import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../products/product.model';


@Component({
  selector: 'app-new-spices',
  templateUrl: './new-spices.component.html',
  styleUrls: ['./new-spices.component.css']
})
export class NewSpicesComponent implements OnInit {

  title:String = "ADD SPICES";
  constructor(private productService: ProductService,private router: Router) { }
  
  productItem= new ProductModel(null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(){
  }

AddSpices()
{
  this.productService.newSpices(this.productItem);
  console.log('called');
  alert('success');
  this.router.navigate(['/products/spices']);
}

}