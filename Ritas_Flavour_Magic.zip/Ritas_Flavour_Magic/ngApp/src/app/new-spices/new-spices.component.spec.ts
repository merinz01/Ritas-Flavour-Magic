import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewSpicesComponent } from './new-spices.component';

describe('NewSpicesComponent', () => {
  let component: NewSpicesComponent;
  let fixture: ComponentFixture<NewSpicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewSpicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewSpicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
