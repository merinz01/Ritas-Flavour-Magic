import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ProductsComponent } from './products/products.component';
import { TestimonialsComponent } from './testimonials/testimonials.component'
import { ContactusComponent} from './contactus/contactus.component'
import { ProductListComponent } from './product-list/product-list.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { NewProductComponent } from './new-product/new-product.component';
import { EditProductsComponent } from './edit-products/edit-products.component';
import { BreakfastComponent } from './breakfast/breakfast.component';
import { MasalasComponent } from './masalas/masalas.component';
import { PicklesComponent } from './pickles/pickles.component';
import { SpicesComponent } from './spices/spices.component';
import { PastesComponent } from './pastes/pastes.component';
import { NewSpicesComponent } from './new-spices/new-spices.component';
import { NewMasalasComponent } from './new-masalas/new-masalas.component';
import { NewPastesComponent } from './new-pastes/new-pastes.component';
import { NewPicklesComponent } from './new-pickles/new-pickles.component';
import { EditSpicesComponent } from './edit-spices/edit-spices.component';
import { EditMasalasComponent } from './edit-masalas/edit-masalas.component';
import { EditPicklesComponent } from './edit-pickles/edit-pickles.component';
import { EditPastesComponent } from './edit-pastes/edit-pastes.component';

// import { UserGuard } from './user.guard';
import { AdminGuard } from './admin.guard';



const routes: Routes = [
  { path:'',
    redirectTo:'home',
    pathMatch:'full'
  },
  { path:"home",
    component: HomeComponent
  },
  { path:"aboutus",
    component: AboutusComponent
  },
  { path:"products",
    component: ProductsComponent,
    canActivate:[AdminGuard],
    // canActivate:[UserGuard],
    children:[
      { path:"breakfast",
        component:BreakfastComponent
    },
    { path:"masalas",
    component:MasalasComponent
    },
    { path:"pickles",
    component:PicklesComponent
    },
    { path:"pastes",
    component:PastesComponent
    },
    { path:"spices",
    component:SpicesComponent
    }
    ]
  },

    // ADD PRODUCTS COMPONENTS 

  { path:'add',
    component: NewProductComponent,
    // canActivate:[UserGuard]
  },
  { path:'addspices',
  component: NewSpicesComponent,
  // canActivate:[UserGuard]
},  
{ path:'addpastes',
component: NewPastesComponent,
// canActivate:[UserGuard]
}, 
{ path:'addmasalas',
component: NewMasalasComponent,
// canActivate:[UserGuard]
}, 
{ path:'addpickles',
component: NewPicklesComponent,
// canActivate:[UserGuard]
}, 
{ path:'add',
component: NewProductComponent,
// canActivate:[UserGuard]
},

// EDIT PROUDUCTS COMPONENTS

{ path:'edit/:id',
  component: EditProductsComponent,
  // canActivate:[UserGuard]
},
{ path:'editspices/:id',
  component: EditSpicesComponent,
  // canActivate:[UserGuard]
},
{ path:'editpastes/:id',
  component: EditPastesComponent,
  // canActivate:[UserGuard]
},
{ path:'editmasalas/:id',
  component: EditMasalasComponent,
  // canActivate:[UserGuard]
},
{ path:'editpickles/:id',
  component: EditPicklesComponent,
  // canActivate:[UserGuard]
},


  { path:"testimonials",
    component: TestimonialsComponent
  },
  { path:"contactus",
    component: ContactusComponent
  },
  { path:"product-list",
    component:ProductListComponent
  },
  { path:'register',
  component: RegisterComponent },
  { path:'login',
    component: LoginComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
