import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AdminGuard } from './admin.guard';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient,private _router:Router){ }
  registerUser(user)
{
  return this.http.post("http://localhost:3000/api/register", user);
} 
  loginUser(user)
{
  console.log(user);
  return this.http.post("http://localhost:3000/api/login", user);
} 

loggedIn()
{
  
  return !!localStorage.getItem('token');
}

logoutUser()
{
  localStorage.removeItem('token')
  this._router.navigate(['/home'])
}
getToken()
{
  return localStorage.getItem('token');
}


isAdmin()
  {
    var email= localStorage.getItem('user');
    if((this.loggedIn())&&(email=="admin"))
    {
        return true;
      }
     else{
       return false;
     }
    }
  }
