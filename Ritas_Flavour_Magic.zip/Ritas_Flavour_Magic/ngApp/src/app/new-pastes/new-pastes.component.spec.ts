import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPastesComponent } from './new-pastes.component';

describe('NewPastesComponent', () => {
  let component: NewPastesComponent;
  let fixture: ComponentFixture<NewPastesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewPastesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewPastesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
