import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../products/product.model';


@Component({
  selector: 'app-new-pastes',
  templateUrl: './new-pastes.component.html',
  styleUrls: ['./new-pastes.component.css']
})
export class NewPastesComponent implements OnInit {

  
  title:String = "ADD PASTES";
  constructor(private productService: ProductService,private router: Router) { }
  
  productItem= new ProductModel(null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(){
  }

AddPastes()
{
  this.productService.newPastes(this.productItem);
  console.log('called');
  alert('success');
  this.router.navigate(['/products/pastes']);
}

}