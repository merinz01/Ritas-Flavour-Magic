import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../products/product.model';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ProductService } from '../product.service';
import { UserService } from '../user.service';
import { UserGuard } from '../user.guard';

@Component({
  selector: 'app-breakfast',
  templateUrl: './breakfast.component.html',
  styleUrls: ['./breakfast.component.css']
})
export class BreakfastComponent implements OnInit {
  title:string = "BREAKFAST"
  public products: ProductModel[];
  imageWidth:number = 50;
  imageMargin:number= 2;
  showImage: boolean = false;
  
  constructor(
    private productService:ProductService,
    private _router:Router,
    public _user:UserGuard,
    public userService:UserService 
  ) { }
 
  toggleImage(): void{
    this.showImage = !this.showImage;
  }
 
  
  deleteProducts(product,index)
  {
    if(window.confirm('Delete permenantly')){
      this.productService.deleteProduct(product._id)
       .subscribe((data)=>{
         this.products.splice(index, 1);
        //  console.log(`Deleted product is ${data}`);
    })
  }
  }

  ngOnInit(): void {
  this.productService.getProducts()
  // .subscribe(
  //   res=>console.log(res),
  //   err=>console.log(err)
  //   )}
  .subscribe((data)=>{
    
  this.products=JSON.parse(JSON.stringify(data))
  console.log(this.products);
},
(err)=>{ if ( err instanceof HttpErrorResponse){ 
  if ( err.status === 401) {
    this._router.navigate(['./login'])
  } }}
  )}

}

