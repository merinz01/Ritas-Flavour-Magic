import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../products/product.model';


@Component({
  selector: 'app-new-pickles',
  templateUrl: './new-pickles.component.html',
  styleUrls: ['./new-pickles.component.css']
})
export class NewPicklesComponent implements OnInit {
  title:String = "ADD PICKLES";
  constructor(private productService: ProductService,private router: Router) { }
  
  productItem= new ProductModel(null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(){
  }

AddPickles()
{
  this.productService.newPickles(this.productItem);
  console.log('called');
  alert('success');
  this.router.navigate(['/products/pickles']);
}

}
