import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPicklesComponent } from './new-pickles.component';

describe('NewPicklesComponent', () => {
  let component: NewPicklesComponent;
  let fixture: ComponentFixture<NewPicklesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewPicklesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewPicklesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
