import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsermasalaComponent } from './usermasala.component';

describe('UsermasalaComponent', () => {
  let component: UsermasalaComponent;
  let fixture: ComponentFixture<UsermasalaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsermasalaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsermasalaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
