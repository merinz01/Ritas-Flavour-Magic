import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usermasala',
  templateUrl: './usermasala.component.html',
  styleUrls: ['./usermasala.component.css']
})
export class UsermasalaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
