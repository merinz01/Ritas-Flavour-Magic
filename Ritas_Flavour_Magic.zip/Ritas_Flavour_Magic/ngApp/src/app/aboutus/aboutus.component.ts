import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  images=['../../assets/images/Ancy.jpg','../../assets/images/Saly.jpg','../../assets/images/Ancy.jpg'];
}
