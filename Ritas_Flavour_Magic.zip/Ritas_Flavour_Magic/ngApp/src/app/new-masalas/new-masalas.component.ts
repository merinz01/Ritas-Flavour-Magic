import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../products/product.model';


@Component({
  selector: 'app-new-masalas',
  templateUrl: './new-masalas.component.html',
  styleUrls: ['./new-masalas.component.css']
})
export class NewMasalasComponent implements OnInit {

 
  title:String = "ADD MASALA";
  constructor(private productService: ProductService,private router: Router) { }
  
  productItem= new ProductModel(null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(){
  }

AddMasalas()
{
  this.productService.newMasalas(this.productItem);
  console.log('called');
  alert('success');
  this.router.navigate(['products/masalas']);
}

}

