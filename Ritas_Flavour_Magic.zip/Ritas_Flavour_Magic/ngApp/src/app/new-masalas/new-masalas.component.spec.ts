import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewMasalasComponent } from './new-masalas.component';

describe('NewMasalasComponent', () => {
  let component: NewMasalasComponent;
  let fixture: ComponentFixture<NewMasalasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewMasalasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewMasalasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
