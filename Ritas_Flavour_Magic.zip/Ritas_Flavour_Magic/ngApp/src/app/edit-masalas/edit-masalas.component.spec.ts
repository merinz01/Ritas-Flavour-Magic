import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMasalasComponent } from './edit-masalas.component';

describe('EditMasalasComponent', () => {
  let component: EditMasalasComponent;
  let fixture: ComponentFixture<EditMasalasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMasalasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMasalasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
