import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute, Router } from "@angular/router";
import { ProductModel } from '../products/product.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-edit-masalas',
  templateUrl: './edit-masalas.component.html',
  styleUrls: ['./edit-masalas.component.css']
})
export class EditMasalasComponent implements OnInit {
  title:string = "EDIT MASALAS";

  public updateMasalas: ProductModel;
  
  
    constructor(private productService: ProductService,
                private router: Router,
                private actRoute: ActivatedRoute) { }
   
  
    ngOnInit(): void {
      let id = this.actRoute.snapshot.paramMap.get('id');
      console.log(id);
      this.showMasalas(id);
    }
  
    showMasalas(id){
      this.productService.showMasalas(id)
      .subscribe((data)=>{
       this.updateMasalas=JSON.parse(JSON.stringify(data))
    })
    }
  
    editMasalas()
    {
      let id = this.actRoute.snapshot.paramMap.get('id');
      console.log('called product with id :'+ id);
  
      if (window.confirm('Update Products')) {
      this.productService.editMasalas(id,this.updateMasalas)
      .subscribe((data)=>{
      this.router.navigate(['/products/masalas']);
      console.log('Content updated successfully!' + data);
      alert('Product Updation Successful!!');
  
      }),(err)=>{console.log(err)}
    }
  }
  }
  