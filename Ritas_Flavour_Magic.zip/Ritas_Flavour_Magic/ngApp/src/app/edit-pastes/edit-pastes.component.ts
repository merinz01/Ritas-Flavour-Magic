import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute, Router } from "@angular/router";
import { ProductModel } from '../products/product.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-edit-pastes',
  templateUrl: './edit-pastes.component.html',
  styleUrls: ['./edit-pastes.component.css']
})
export class EditPastesComponent implements OnInit {
  title:string = "EDIT PASTES";

  public updatePastes: ProductModel;
  
  
    constructor(private productService: ProductService,
                private router: Router,
                private actRoute: ActivatedRoute) { }
   
  
    ngOnInit(): void {
      let id = this.actRoute.snapshot.paramMap.get('id');
      console.log(id);
      this.showPastes(id);
    }
  
    showPastes(id){
      this.productService.showPastes(id)
      .subscribe((data)=>{
       this.updatePastes=JSON.parse(JSON.stringify(data))
    })
    }
  
    editPastes()
    {
      let id = this.actRoute.snapshot.paramMap.get('id');
      console.log('called product with id :'+ id);
  
      if (window.confirm('Update Products')) {
      this.productService.editPastes(id,this.updatePastes)
      .subscribe((data)=>{
      this.router.navigate(['/products/pastes']);
      console.log('Content updated successfully!' + data);
      alert('Product Updation Successful!!');
  
      }),(err)=>{console.log(err)}
    }
  }
  }