import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPastesComponent } from './edit-pastes.component';

describe('EditPastesComponent', () => {
  let component: EditPastesComponent;
  let fixture: ComponentFixture<EditPastesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPastesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPastesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
