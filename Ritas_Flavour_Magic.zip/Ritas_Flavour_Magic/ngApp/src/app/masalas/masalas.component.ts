import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../products/product.model';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { UserService } from '../user.service';
import { UserGuard } from '../user.guard';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-masalas',
  templateUrl: './masalas.component.html',
  styleUrls: ['./masalas.component.css']
})
export class MasalasComponent implements OnInit {

  title:string = "MASALAS"
  public masalas: ProductModel[];
  imageWidth:number = 50;
  imageMargin:number= 2;
  showImage: boolean = false;
  
  constructor(
    private productService:ProductService,
    private _router:Router,
    public _user:UserGuard,
    public userService:UserService 
  ) { }
 
  toggleImage(): void{
    this.showImage = !this.showImage;
  }

  deleteMasalas(product,index)
  {
    if(window.confirm('Delete permenantly')){
      this.productService.deleteMasalas(product._id)
       .subscribe((data)=>{
         this.masalas.splice(index, 1);
        //  console.log(`Deleted product is ${data}`);
    })
  }
  }

  ngOnInit(): void {
  this.productService.getMasalas()
  // .subscribe(
  //   res=>console.log(res),
  //   err=>console.log(err)
  //   )}
  .subscribe((data)=>{
    
  this.masalas=JSON.parse(JSON.stringify(data))
  console.log(this.masalas);
},
(err)=>{ if ( err instanceof HttpErrorResponse){ 
  if ( err.status === 401) {
    this._router.navigate(['./login'])
  } }}
  )}

}