import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasalasComponent } from './masalas.component';

describe('MasalasComponent', () => {
  let component: MasalasComponent;
  let fixture: ComponentFixture<MasalasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasalasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasalasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
