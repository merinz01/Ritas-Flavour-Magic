import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute, Router } from "@angular/router";
import { ProductModel } from '../products/product.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-edit-spices',
  templateUrl: './edit-spices.component.html',
  styleUrls: ['./edit-spices.component.css']
})
export class EditSpicesComponent implements OnInit {
  title:string = "Edit Spices";

  public updateSpice: ProductModel;
  
  
    constructor(private productService: ProductService,
                private router: Router,
                private actRoute: ActivatedRoute) { }
   
  
    ngOnInit(): void {
      let id = this.actRoute.snapshot.paramMap.get('id');
      console.log(id);
      this.showSpices(id);
    }
  
    showSpices(id){
      this.productService.showSpices(id)
      .subscribe((data)=>{
       this.updateSpice=JSON.parse(JSON.stringify(data))
    })
    }
  
    editSpices()
    {
      let id = this.actRoute.snapshot.paramMap.get('id');
      console.log('called product with id :'+ id);
  
      if (window.confirm('Update Products')) {
      this.productService.editSpices(id,this.updateSpice)
      .subscribe((data)=>{
      this.router.navigate(['/products/spices']);
      console.log('Content updated successfully!' + data);
      alert('Product Updation Successful!!');
  
      }),(err)=>{console.log(err)}
    }
  }
  }