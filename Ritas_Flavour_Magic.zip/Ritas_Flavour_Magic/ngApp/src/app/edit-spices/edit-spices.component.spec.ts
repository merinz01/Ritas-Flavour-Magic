import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSpicesComponent } from './edit-spices.component';

describe('EditSpicesComponent', () => {
  let component: EditSpicesComponent;
  let fixture: ComponentFixture<EditSpicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditSpicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSpicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
