import { Component, OnInit } from '@angular/core';
// import { ProductModel } from '../products/product.model';
// import { Router } from '@angular/router';
// import { ProductService } from '../product.service';
// import { UserService } from '../user.service';
// import { UserGuard } from '../user.guard';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  // title:string = "Products List"
  // public products: ProductModel[];
  // imageWidth:number = 50;
  // imageMargin:number= 2;
  // showImage: boolean = false;
  
  constructor(
    // private productService:ProductService,
    // private _router:Router,
    // public _user:UserGuard,
    // public userService:UserService 
  ) { }
 
  // toggleImage(): void{
  //   this.showImage = !this.showImage;
  // }

  ngOnInit(): void {}
  // this.productService.getProducts()
  // .subscribe(
  //   res=>console.log(res),
  //   err=>console.log(err)
  //   )}
  // .subscribe((data)=>{
    
  // this.products=JSON.parse(JSON.stringify(data))
  // console.log(this.products);
// }
//   )}
images = ['../../assets/images/chilly.jpg','../../assets/images/pepper.png','../../assets/images/coriander.jpg','../../assets/images/turmeric.jpg','../../assets/images/kashimiri.jpg','../../assets/images/cumin.jpg',
'../../assets/images/garam.jpg','../../assets/images/sambar.jpg','../../assets/images/egg.png','../../assets/images/veg.jpg','../../assets/images/chicken.jpg','../../assets/images/biriyani.jpg',
'../../assets/images/mango.jpg','../../assets/images/lime.jpg','../../assets/images/garlic.jpg','../../assets/images/fish.jpg','../../assets/images/prawn.jpg','../../assets/images/mixveg.jpg',
'../../assets/images/puttu.jpg','../../assets/images/idli.jpg','../../assets/images/appam.jpg','../../assets/images/dosa.jpg','../../assets/images/pathiri.jpg','../../assets/images/chemba.jpg',
'../../assets/images/tamarind.jpg','../../assets/images/gingergarlic.jpg','../../assets/images/gingergarlic.jpg','../../assets/images/gingergarlic.jpg'];
}
