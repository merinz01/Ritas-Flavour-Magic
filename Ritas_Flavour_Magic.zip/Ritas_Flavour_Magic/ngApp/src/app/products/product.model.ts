export class ProductModel{

    constructor(
        // public _id:string,
        public category:string,
        public productId:number,
        public productName:string,
        public productCode:string,
        public description:string,
        public hundredgm:number,
        public twohundredgm:number,
        public fivehundredgm:number,
        public onekg:number,
        public price:string,
        public imageUrl:string){}

}