import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPicklesComponent } from './edit-pickles.component';

describe('EditPicklesComponent', () => {
  let component: EditPicklesComponent;
  let fixture: ComponentFixture<EditPicklesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPicklesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPicklesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
