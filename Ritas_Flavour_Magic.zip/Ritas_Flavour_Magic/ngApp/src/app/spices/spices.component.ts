import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../products/product.model';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { UserService } from '../user.service';
import { UserGuard } from '../user.guard';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-spices',
  templateUrl: './spices.component.html',
  styleUrls: ['./spices.component.css']
})
export class SpicesComponent implements OnInit {

  title:string = "SPICES"
  public spices: ProductModel[];
  imageWidth:number = 50;
  imageMargin:number= 2;
  showImage: boolean = false;
  
  constructor(
    private productService:ProductService,
    private _router:Router,
    public _user:UserGuard,
    public userService:UserService 
  ) { }
 
  toggleImage(): void{
    this.showImage = !this.showImage;
  }

  deleteSpices(product,index)
  {
    if(window.confirm('Delete permenantly')){
      this.productService.deleteSpices(product._id)
       .subscribe((data)=>{
         this.spices.splice(index, 1);
        //  console.log(`Deleted product is ${data}`);
    })
  }
  
  }

  ngOnInit(): void {
  this.productService.getSpices()
  // .subscribe(
  //   res=>console.log(res),
  //   err=>console.log(err)
  //   )}
  .subscribe((data)=>{
    
  this.spices=JSON.parse(JSON.stringify(data))
  console.log(this.spices);
},
(err)=>{ if ( err instanceof HttpErrorResponse){ 
  if ( err.status === 401) {
    this._router.navigate(['./login'])
  } }}
  )}

}

