import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../products/product.model';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { UserService } from '../user.service';
import { UserGuard } from '../user.guard';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-pickles',
  templateUrl: './pickles.component.html',
  styleUrls: ['./pickles.component.css']
})
export class PicklesComponent implements OnInit {

  title:string = "PICKLES"
  public pickles: ProductModel[];
  imageWidth:number = 50;
  imageMargin:number= 2;
  showImage: boolean = false;
  
  constructor(
    private productService:ProductService,
    private _router:Router,
    public _user:UserGuard,
    public userService:UserService 
  ) { }
 
  toggleImage(): void{
    this.showImage = !this.showImage;
  }

  deletePickles(product,index)
  {
    if(window.confirm('Delete permenantly')){
      this.productService.deletePickles(product._id)
       .subscribe((data)=>{
         this.pickles.splice(index, 1);
        //  console.log(`Deleted product is ${data}`);
    })
  }
  
  }

  ngOnInit(): void {
  this.productService.getPickles()
  // .subscribe(
  //   res=>console.log(res),
  //   err=>console.log(err)
  //   )}
  .subscribe((data)=>{
    
  this.pickles=JSON.parse(JSON.stringify(data))
  console.log(this.pickles);
},
(err)=>{ if ( err instanceof HttpErrorResponse){ 
  if ( err.status === 401) {
    this._router.navigate(['./login'])
  } }}
  )}

}

