import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

   baseUri:string = 'http://localhost:3000/api';
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private http:HttpClient) { }
  getProducts(){
    let url=`${this.baseUri}/products`
    return this.http.get(url);
  }
  getMasalas(){
    let url=`${this.baseUri}/masalas`
    return this.http.get(url);
  }
  getPickles(){
    let url=`${this.baseUri}/pickles`
    return this.http.get(url);
  }
  getPastes(){
    let url=`${this.baseUri}/pastes`
    return this.http.get(url);
  }
  getSpices(){
    let url=`${this.baseUri}/spices`
    return this.http.get(url);
  }

// BREAKFAST
  newProduct(item){
    let url = `${this.baseUri}/add`
    return this.http.post(url,{'product':item})
    .subscribe((data)=>{console.log(data)})
  }


  showProduct(id:any){
    let url=`${this.baseUri}/edit/${id}`
    return this.http.get(url)
    // .subscribe((data)=>{console.log(data)})
  }
  editProduct(id:any,item){
    let url=`${this.baseUri}/update/${id}`
    return this.http.post(url,item)
    // .subscribe((data)=>{console.log(data)})
  }

  deleteProduct(id:any) {
    let url=`${this.baseUri}/delete/${id}`;
    return this.http.delete(url, { headers: this.headers })
  }

  // MASALAS
  newMasalas(item){
    let url = `${this.baseUri}/addMasalas`
    return this.http.post(url,{'masala':item})
    .subscribe((data)=>{console.log(data)})
  }


  showMasalas(id:any){
    let url=`${this.baseUri}/editMasalas/${id}`
    return this.http.get(url)
    // .subscribe((data)=>{console.log(data)})
  }
  editMasalas(id:any,item){
    let url=`${this.baseUri}/updateMasalas/${id}`
    return this.http.post(url,item)
    // .subscribe((data)=>{console.log(data)})
  }

  deleteMasalas(id:any) {
    let url=`${this.baseUri}/deleteMasalas/${id}`;
    return this.http.delete(url, { headers: this.headers })
  }

  // PICKLES
  newPickles(item){
    let url = `${this.baseUri}/addPickles`
    return this.http.post(url,{'pickle':item})
    .subscribe((data)=>{console.log(data)})
  }


  showPickles(id:any){
    let url=`${this.baseUri}/editPickles/${id}`
    return this.http.get(url)
    // .subscribe((data)=>{console.log(data)})
  }
  editPickles(id:any,item){
    let url=`${this.baseUri}/updatePickles/${id}`
    return this.http.post(url,item)
    // .subscribe((data)=>{console.log(data)})
  }

  deletePickles(id:any) {
    let url=`${this.baseUri}/deletePickles/${id}`;
    return this.http.delete(url, { headers: this.headers })
  }

  // PASTES
  newPastes(item){
    let url = `${this.baseUri}/addPastes`
    return this.http.post(url,{'paste':item})
    .subscribe((data)=>{console.log(data)})
  }


  showPastes(id:any){
    let url=`${this.baseUri}/editPastes/${id}`
    return this.http.get(url)
    // .subscribe((data)=>{console.log(data)})
  }
  editPastes(id:any,item){
    let url=`${this.baseUri}/updatePastes/${id}`
    return this.http.post(url,item)
    // .subscribe((data)=>{console.log(data)})
  }

  deletePastes(id:any) {
    let url=`${this.baseUri}/deletePastes/${id}`;
    return this.http.delete(url, { headers: this.headers })
  }

  // SPICES
  newSpices(item){
    let url = `${this.baseUri}/addSpices`
    return this.http.post(url,{'spice':item})
    .subscribe((data)=>{console.log(data)})
  }


  showSpices(id:any){
    let url=`${this.baseUri}/editSpices/${id}`
    return this.http.get(url)
    // .subscribe((data)=>{console.log(data)})
  }
  editSpices(id:any,item){
    let url=`${this.baseUri}/updateSpices/${id}`
    return this.http.post(url,item)
    // .subscribe((data)=>{console.log(data)})
  }

  deleteSpices(id:any) {
    let url=`${this.baseUri}/deleteSpices/${id}`;
    return this.http.delete(url, { headers: this.headers })
  }


}
